#include <SFML/Graphics.hpp> //j'ai utilis� la biblioth�que SFML pour faire l'interface graphique
#include <SFML/Window.hpp>
#include  <iostream>
#include <SFML/Audio.hpp>
#include <cstdlib>

int positionx=5*50;
int positiony=5*50;
int positionx2=0;
int positiony2=0;
int mur_droite;
int valeur;
char tab[16][12];
char tab2[16][12];
int murx=5,mury=5,murx_ghost=0;
int v=0;
int perdu,win;
int bouton;


using namespace sf;
using namespace std;

void fantomes_limites() //fonction pour pas que le fantome d�passe pas de la map
{

if (positionx2>15)
{
    positionx2=15;

}
else if(positionx2<0)
{
    positionx2=0;
}
else if(positiony2>11)
{
    positiony2=11;
}
else if(positiony2<0)
{
    positiony2=0;
}

}

void mouvement()
{
    if (positionx > 750)
    {
        positionx=750;
    }
    else if (positionx <0)
    {
        positionx=0;
    }
    else if(positiony<0)
    {
        positiony=0;
    }
    else if(positiony>550)
    {
        positiony=550;
    }

}

//les 4 fonctions pour pas que pacman touche le mur en fonction des 4 directions

void arretmur()
{
    if (tab[murx][mury]=='#')
    {
        murx=murx-1;
    }
    else
    {
        positionx=positionx+50;


        mouvement();

    }
}
void arretmur2()
{
    if (tab[murx][mury]=='#')
    {
        murx=murx+1;
    }
    else
    {
        positionx=positionx-50;

        mouvement();

    }
}
void arretmur3()
{
    if (tab[murx][mury]=='#')
    {
        mury=mury-1;
    }
    else
    {
        positiony=positiony+50;

        mouvement();

    }
}
void arretmur4()
{
    if (tab[murx][mury]=='#')
    {
        mury=mury+1;
    }
    else
    {
        positiony=positiony-50;

        mouvement();

    }
}


void mapp() // on cr�e les diff�rents mur (je voyais pas d'autre moyen de le faire sans le faire � la main)
{
    tab[5][5]='X';
    tab[5][3]='#';
    tab[4][3]='#';
    tab[3][3]='#';
    tab[3][4]='#';
    tab[3][5]='#';
    tab[3][6]='#';
    tab[3][7]='#';
    tab[3][8]='#';
    tab[4][8]='#';
    tab[5][8]='#';

    tab[10][3]='#';
    tab[11][3]='#';
    tab[12][3]='#';
    tab[12][4]='#';
    tab[12][5]='#';
    tab[12][6]='#';
    tab[12][7]='#';
    tab[12][8]='#';
    tab[11][8]='#';
    tab[10][8]='#';
    tab[7][4]='#';
    tab[8][4]='#';
    tab[6][8]='#';
    tab[9][8]='#';
    tab[6][5]='#';
    tab[5][6]='#';
    tab[9][5]='#';
    tab[10][6]='#';
    tab[2][1]='#';
    tab[1][1]='#';
    tab[1][2]='#';
    tab[13][1]='#';
    tab[14][1]='#';
    tab[14][2]='#';
    tab[1][9]='#';
    tab[1][10]='#';
    tab[2][10]='#';
    tab[14][9]='#';
    tab[14][10]='#';
    tab[13][10]='#';

    tab[7][0]='#';
    tab[8][0]='#';
    tab[6][1]='#';
    tab[7][1]='#';
    tab[8][1]='#';
    tab[9][1]='#';

    tab[6][10]='#';
    tab[7][10]='#';
    tab[8][10]='#';
    tab[9][10]='#';
    tab[7][11]='#';
    tab[8][11]='#';
}

void initialisation() //on initialise le tableau
{
    for(int i=0; i<16; i++)
    {
        for(int j=0; j<12; j++)
        {
            tab[i][j]='!';
            tab2[i][j]='!';
        }
    }

}

void manger() //fonction pour que pacman mange le point
{
    tab[murx][mury]='X';



}
int main()
{

//pour ins�rer du son mais il y a une erreur avec le fichier


    /*sf::SoundBuffer buffer;
    if (!buffer.loadFromFile("jeu.wav"))
    {
        cout<<"error";
    }
    Sound sound;
    sound.setBuffer(buffer);

    // son si on gagne
    SoundBuffer win;
    if (!win.loadFromFile("win.wav"))
    {
        cout<<"error";
    }
    Sound sound_win;
    sound_win.setBuffer(win);*/


    // ici j'inc�re une police pour le message quand on a gagn�

    sf::Font font;
    if (!font.loadFromFile("Game Of Squids.ttf"))
    {
        // erreur...
    }
    Text text;
    text.setFont(font);
    text.setString("WIN");
    text.setCharacterSize(300);
    text.setFillColor(sf::Color::Red);
    text.setPosition(90,90);

    Text text_lost;
    text_lost.setFont(font);
    text_lost.setString("GAME OVER");
    text_lost.setCharacterSize(100);
    text_lost.setFillColor(sf::Color::Red);
    text_lost.setPosition(90,190);

    Text text_pacman;
    text_pacman.setFont(font);
    text_pacman.setString("PACMAN");
    text_pacman.setCharacterSize(130);
    text_pacman.setFillColor(sf::Color::Blue);
    text_pacman.setPosition(140,30);

    Text text_by;
    text_by.setFont(font);
    text_by.setString("by EiSiNe");
    text_by.setCharacterSize(60);
    text_by.setFillColor(sf::Color::Red);
    text_by.setPosition(380,150);

    Text text_clique;
    text_clique.setFont(font);
    text_clique.setString("press SPACE to play");
    text_clique.setCharacterSize(20);
    text_clique.setFillColor(sf::Color::White);
    text_clique.setPosition(250,350);

    Text text_gabin;
    text_gabin.setFont(font);
    text_gabin.setString("Gabin");
    text_gabin.setCharacterSize(20);
    text_gabin.setFillColor(sf::Color::White);
    text_gabin.setPosition(550,550);


    //ici je cr�e la fen�tre du jeu

    sf::RenderWindow window;
    window.create(VideoMode(800, 600), "My window");
    window.setTitle("PACMAN");


    //ici je cr�e les formes du plateau de jeu



    RectangleShape tableau_carre(sf::Vector2f(50.f, 50.f)); //case vide la ou il n'y a pas de mur
    tableau_carre.setFillColor(sf::Color(0,0,0));
    tableau_carre.setOutlineColor(sf::Color(0, 0, 255));


    RectangleShape tableau_carre2(sf::Vector2f(50.f, 50.f)); //case vide apr�s que pacman ai mang� le point
    tableau_carre2.setFillColor(sf::Color(0,0,0));
    tableau_carre2.setOutlineColor(sf::Color(0, 0, 255));

    RectangleShape bouton_jouer(sf::Vector2f(200.f, 70.f)); //bouton play
    bouton_jouer.setFillColor(sf::Color(255,0,0));
    bouton_jouer.setOutlineColor(sf::Color(25, 199,0));


    sf::Clock clock; // on initialise une unit� de temps
    sf::Clock clock2;

    CircleShape cercle(5); // le point que pacman mange
    cercle.setFillColor(sf::Color(215,215,215));
    initialisation();

        //le pacman
    sf::Texture texture_right;
    if (!texture_right.loadFromFile("pacman.png"))
        return EXIT_FAILURE;

        Sprite pacman;



//pacman de cot� en haut et droite, une image pour chaque direction que pacman prends
      sf::Texture texture_left;
    if (!texture_left.loadFromFile("pacman_left.png"))
        return EXIT_FAILURE;

          sf::Texture texture_up;
    if (!texture_up.loadFromFile("pacman_up.png"))
        return EXIT_FAILURE;

      sf::Texture texture_down;
    if (!texture_down.loadFromFile("pacman_down.png"))
        return EXIT_FAILURE;
         pacman.setTexture(texture_right);




// les murs

      sf::Texture texture_mur;
    if (!texture_mur.loadFromFile("mur.png"))
        return EXIT_FAILURE;
        Sprite murr;
         murr.setTexture(texture_mur);

//fantomes
              sf::Texture texture_ghost_blue;
    if (!texture_ghost_blue.loadFromFile("ghost_blue.png"))
        return EXIT_FAILURE;
        Sprite ghost_blue;
         ghost_blue.setTexture(texture_ghost_blue);



//tant que la fen�tre est ouverte
    while(window.isOpen())
    {
        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
            {
                window.close(); // si on clique sur le bouton fermer
            }

        }

        float time = clock.getElapsedTime().asSeconds();   //unit� de temps tout est en seconde
        float time2 = clock2.getElapsedTime().asSeconds();
        float delay=0.1;
        float delay_ghost=0.5;
        float delay3=0.3;



        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) //si la touche fleche droite est pr�ss�, et que le temps est sup�rieur au delai que j'ai fix�

        {
            if(time>delay)
            {
                murx=murx+1;
                if(murx>=15) //pour pas que pacman d�passe de la map
                {
                    murx=murx=15;
                }
                arretmur(); //fonction pour pas que pacman cogne dans les murs
                manger();

                 pacman.setTexture(texture_right);

                clock.restart(); //on remet le temps a 0
            }
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
        {
            if(time>delay)
            {

                murx=murx-1;
                if(murx<=0)
                {
                    murx=murx=0;
                }
                arretmur2();
                manger();

                pacman.setTexture(texture_left);
                clock.restart();

            }
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
        {
            if(time>delay)
            {
                mury=mury+1;
                if(mury>=11)
                {
                    mury=mury=11;
                }
                arretmur3();
                manger();

                pacman.setTexture(texture_down);
                clock.restart();
            }
        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
        {

            if(time>delay)
            {
                mury=mury-1;
                if(mury<0)
                {
                    mury=mury=0;
                }
                arretmur4();
                manger();

                pacman.setTexture(texture_up);
                clock.restart();
            }
        }
        pacman.setPosition(positionx,positiony); //gr�ce � la fonction mouvement pacman prend une position en fonction des touches

        mapp(); //on initialise la map avec les mur


            // fantomes

            if(time2>delay_ghost)
                {
                  v=rand()%7;



                  if((v==0)||(v==4))
                  {
                       positionx2=positionx2 +1;
                       if (tab[positionx2][positiony2]=='#')
                       {
                           positionx2=positionx2-1;

                       }
                  }
                  else if ((v==1)||(v==5))
                  {

                       positiony2=positiony2+1;
                       if (tab[positionx2][positiony2]=='#')
                       {
                           positiony2=positiony2-1;
                       }

                  }
                  else if((v==2)||(v==6))
                  {
                      positionx2=positionx2 -1;
                      if (tab[positionx2][positiony2]=='#')
                       {
                           positionx2=positionx2+1;
                       }

                  }
                  else if((v==3)||(v==7))
                  {
                       positiony2=positiony2-1;
                       if (tab[positionx2][positiony2]=='#')
                       {
                           positiony2=positiony2=1;
                       }
                  }

                  fantomes_limites();



                  ghost_blue.setPosition(positionx2*50,positiony2*50);






                    clock2.restart();

                }


        window.clear();

        if (bouton==false)
        {
            bouton_jouer.setPosition(6*50,8*50);
            window.draw(text_pacman);
            window.draw(text_by);
            window.draw(text_clique);
            window.draw(text_gabin);

            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
            {
                bouton=true;
            }
        }
        else
        {

                for(int aa=0; aa<16; aa++)
                {

                    for(int bb=0; bb<12; bb++)
                    {
                        int positionaa,positionbb;

                        positionaa=aa*50;
                        positionbb=bb*50;


                        if(tab[aa][bb]=='#')
                        {

                            murr.setPosition(positionaa,positionbb);
                            window.draw(murr); // on dessine les mur avec la texture

                        }
                        else
                        {
                            tableau_carre.setPosition(positionaa,positionbb);
                            window.draw(tableau_carre); // on dessine les cases vide, ou ils n'y a pas de mur

                            cercle.setPosition(positionaa+17,positionbb+17);
                            window.draw(cercle);  // on dessine les points que l'on manges



                            if (tab[aa][bb]=='X')
                            {
                                tableau_carre2.setPosition(positionaa,positionbb);
                                window.draw(tableau_carre2);

                            }
                        }
                        if (tab2[murx][mury]=='!')
                        {

                            valeur=valeur+1;
                            tab2[murx][mury]='G';
                        }

                        if(valeur>=140) //si tous les points sont mang�s par pacman
                        {
                            win= true;

                        }
                        if((positionx2*50==positionx)&&(positiony2*50==positiony)) //si le fantome touche pacman
                        {
                           perdu = true;

                        }


                    }
                }
                window.draw(ghost_blue);
                window.draw(pacman);

                 if(perdu==true) //alors la partie est perdu
                        {
                            window.clear();
                            initialisation();
                            window.draw(text_lost);
                        }
                else if(win==true)
                {
                    window.clear();
                    initialisation();
                    window.draw(text);

                }

        }


        window.display();



    }
    return 0;
}


