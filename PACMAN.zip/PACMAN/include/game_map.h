#ifndef GAME_MAP_H
#define GAME_MAP_H


class game_map
{
    public:
        game_map();
        virtual ~game_map();

    protected:

    private:
};

#endif // GAME_MAP_H
