#include "game_map.h"

game_map::game_map()
{
    //ctor
}

game_map::~game_map()
{
    //dtor
}
